const APP_DATA = {
  meta: {
    name: "职安盾 VeriWork",
    version: "2.1.0-demo",
    updated: "2026-10-01",
    disclaimer: "本系统用于就业风险提示、普法教育和材料整理，不替代律师、仲裁机构或人社部门作出最终法律判断。"
  },

  lawCorpus: [
    {
      id: "lcl_10_82",
      title: "书面劳动合同与二倍工资",
      source: "《中华人民共和国劳动合同法》第十条、第八十二条",
      authority: "全国人民代表大会常务委员会",
      summary: "建立劳动关系应订立书面劳动合同。已建立劳动关系但未同时订立书面合同的，应自用工之日起一个月内订立；超过一个月未订立，存在二倍工资责任风险。",
      url: "https://flk.npc.gov.cn/",
      tags: ["书面合同", "二倍工资", "一个月"]
    },
    {
      id: "lcl_19",
      title: "试用期期限与次数",
      source: "《中华人民共和国劳动合同法》第十九条",
      authority: "全国人民代表大会常务委员会",
      summary: "试用期长短与劳动合同期限对应；三年以上固定期限和无固定期限合同，试用期不得超过六个月。同一用人单位与同一劳动者只能约定一次试用期。",
      url: "https://flk.npc.gov.cn/",
      tags: ["试用期", "六个月", "只能约定一次"]
    },
    {
      id: "lcl_20",
      title: "试用期工资底线",
      source: "《中华人民共和国劳动合同法》第二十条",
      authority: "全国人民代表大会常务委员会",
      summary: "劳动者在试用期的工资不得低于本单位相同岗位最低档工资或者劳动合同约定工资的百分之八十，并不得低于用人单位所在地的最低工资标准。",
      url: "https://flk.npc.gov.cn/",
      tags: ["试用期工资", "80%", "最低工资"]
    },
    {
      id: "lcl_9",
      title: "禁止收取财物和扣押证件",
      source: "《中华人民共和国劳动合同法》第九条",
      authority: "全国人民代表大会常务委员会",
      summary: "用人单位招用劳动者，不得扣押居民身份证和其他证件，不得要求劳动者提供担保或者以其他名义向劳动者收取财物。",
      url: "https://flk.npc.gov.cn/",
      tags: ["押金", "保证金", "扣押证件", "收费"]
    },
    {
      id: "lcl_26",
      title: "无效或部分无效条款",
      source: "《中华人民共和国劳动合同法》第二十六条",
      authority: "全国人民代表大会常务委员会",
      summary: "以欺诈、胁迫手段或者乘人之危订立的合同，以及免除用人单位法定责任、排除劳动者权利的条款，可能无效或部分无效。",
      url: "https://flk.npc.gov.cn/",
      tags: ["无效条款", "排除权利", "免除责任"]
    },
    {
      id: "lcl_23_24",
      title: "竞业限制人员、期限与补偿",
      source: "《中华人民共和国劳动合同法》第二十三条、第二十四条",
      authority: "全国人民代表大会常务委员会",
      summary: "竞业限制人员限于高级管理人员、高级技术人员和其他负有保密义务的人员，期限不得超过二年；对负有保密义务的劳动者，应约定并支付经济补偿。",
      url: "https://flk.npc.gov.cn/",
      tags: ["竞业限制", "两年", "经济补偿"]
    },
    {
      id: "labor_41_44",
      title: "加班安排与加班费",
      source: "《中华人民共和国劳动法》第四十一条、第四十四条",
      authority: "全国人民代表大会常务委员会",
      summary: "延长工作时间应符合法定程序和时长限制，并依法支付高于正常工作时间的工资报酬。用人单位不得以“自愿”名义排除法定加班费责任。",
      url: "https://flk.npc.gov.cn/",
      tags: ["加班", "加班费", "工时"]
    },
    {
      id: "labor_50_wage",
      title: "工资支付与不得克扣拖欠",
      source: "《中华人民共和国劳动法》第五十条",
      authority: "全国人民代表大会常务委员会",
      summary: "工资应当以货币形式按月支付给劳动者本人，不得克扣或者无故拖欠劳动者的工资。",
      url: "https://flk.npc.gov.cn/",
      tags: ["拖欠工资", "克扣", "按月支付"]
    },
    {
      id: "lcl_35",
      title: "合同变更应协商一致",
      source: "《中华人民共和国劳动合同法》第三十五条",
      authority: "全国人民代表大会常务委员会",
      summary: "变更劳动合同约定内容，应当由用人单位与劳动者协商一致，并采用书面形式。",
      url: "https://flk.npc.gov.cn/",
      tags: ["调岗", "调薪", "协商一致"]
    },
    {
      id: "lcl_37",
      title: "劳动者提前通知解除合同",
      source: "《中华人民共和国劳动合同法》第三十七条",
      authority: "全国人民代表大会常务委员会",
      summary: "劳动者提前三十日以书面形式通知用人单位，可以解除劳动合同；在试用期内提前三日通知即可。",
      url: "https://flk.npc.gov.cn/",
      tags: ["辞职", "三十日", "试用期三日"]
    },
    {
      id: "lcl_38_46_47",
      title: "解除情形与经济补偿",
      source: "《中华人民共和国劳动合同法》第三十八条、第四十六条、第四十七条",
      authority: "全国人民代表大会常务委员会",
      summary: "用人单位未及时足额支付劳动报酬、未依法缴纳社保等情形下，劳动者可以解除合同并可能获得经济补偿；补偿按法定标准计算。",
      url: "https://flk.npc.gov.cn/",
      tags: ["未缴社保", "欠薪", "经济补偿"]
    },
    {
      id: "lcl_85",
      title: "拖欠工资等行为的法律后果",
      source: "《中华人民共和国劳动合同法》第八十五条",
      authority: "全国人民代表大会常务委员会",
      summary: "未及时足额支付劳动报酬、低于最低工资标准支付工资、未依法支付加班费或经济补偿的，劳动行政部门可责令限期支付；逾期不支付还存在加付赔偿金风险。",
      url: "https://flk.npc.gov.cn/",
      tags: ["欠薪", "最低工资", "加付赔偿金"]
    },
    {
      id: "social_58_60",
      title: "社会保险登记与依法缴纳",
      source: "《中华人民共和国社会保险法》第五十八条、第六十条",
      authority: "全国人民代表大会常务委员会",
      summary: "用人单位应依法为职工办理社会保险登记并按时足额缴纳社会保险费，不得与劳动者约定放弃法定缴费义务。",
      url: "https://flk.npc.gov.cn/",
      tags: ["社保", "放弃社保", "登记"]
    },
    {
      id: "employment_27",
      title: "平等就业与反歧视",
      source: "《中华人民共和国就业促进法》第二十七条",
      authority: "全国人民代表大会常务委员会",
      summary: "用人单位招用人员应依法保障劳动者平等就业权利，不得实施就业歧视。以婚育、性别等与岗位无关条件限制就业存在合规风险。",
      url: "https://flk.npc.gov.cn/",
      tags: ["怀孕", "婚育", "性别歧视", "平等就业"]
},
    {
      id: "wage_payment_9_15",
      title: "工资支付与离职结算",
      source: "《工资支付暂行规定》第九条、第十五条",
      authority: "劳动部",
      summary: "劳动关系解除或终止时应一次付清工资；不得克扣或无故拖欠劳动者工资。",
      url: "https://www.gov.cn/",
      tags: ["离职结算", "克扣工资", "欠薪"]
    },
    {
      id: "civil_code_contract",
      title: "格式条款与合同公平",
      source: "《中华人民共和国民法典》第四百九十六条、第四百九十七条",
      authority: "全国人民代表大会",
      summary: "格式条款应提示说明；不合理免除责任、加重对方责任或限制主要权利的条款可能无效。",
      url: "https://flk.npc.gov.cn/",
      tags: ["格式条款", "显失公平", "无效条款"]
    },
    {
      id: "labor_relationship_notice",
      title: "事实劳动关系判断要素",
      source: "《关于确立劳动关系有关事项的通知》（劳社部发〔2005〕12号）",
      authority: "劳动和社会保障部",
      summary: "判断劳动关系应综合主体资格、劳动管理、报酬支付和业务组成等事实，不能只看协议名称。",
      url: "https://www.gov.cn/",
      tags: ["事实劳动关系", "用工管理", "协议名称"]
    },
    {
      id: "internship_policy",
      title: "高校实习管理与实习协议要求",
      source: "教育部关于加强和规范普通本科高校实习管理工作的意见（教高函〔2019〕12号）",
      authority: "教育部",
      summary: "高校实习应完善实习协议、安全教育、过程管理和权益保障；具体适用需结合学校制度和属地要求核验。",
      url: "https://www.moe.gov.cn/",
      tags: ["实习协议", "学校管理", "权益保障"]
    },
{
      id: "tripartite_policy",
      title: "高校毕业生就业协议管理",
      source: "教育部《普通高等学校毕业生就业工作暂行规定》（教学〔1997〕6号）及现行高校毕业生就业工作规定",
      authority: "教育部",
      summary: "三方协议用于明确毕业生、学校和用人单位的就业安排，但不等同于劳动合同；违约金、档案、户口和报到安排应明确、可执行。",
      url: "https://www.moe.gov.cn/",
      tags: ["三方协议", "就业协议", "违约金", "档案", "报到证"]
    }
  ],

  riskPatterns: [
    {
      id: "no_social_insurance",
      title: "约定不缴或放弃社会保险",
      category: "社会保障",
      severity: "high",
      weight: 22,
      confidence: 0.97,
      regex: "(?:不|不予|不再|无需|拒绝)[^。；\\n]{0,8}(?:缴纳|购买|办理)[^。；\\n]{0,8}社保|自愿放弃[^。；\\n]{0,10}(?:社保|社会保险)|社保补贴代替社保|无需[^。；\\n]{0,8}(?:办理|缴纳|购买)[^。；\\n]{0,8}(?:社保|社会保险)",
      reason: "依法参加社会保险属于用人单位和劳动者的法定义务，通常不能通过“自愿放弃”或现金补贴有效排除。",
      action: "要求书面确认社保缴纳主体、起始月份和基数，并要求删除放弃社保条款。",
      lawIds: ["social_58_60", "lcl_26", "lcl_38_46_47"]
    },
    {
      id: "employment_deposit",
      title: "押金、保证金或扣押证件",
      category: "入职收费",
      severity: "high",
      weight: 20,
      confidence: 0.96,
      regex: "(?:押金|保证金|设备押金|服装费|扣留身份证|扣押身份证|提交证件原件|身份证原件由公司保管)",
      exceptionRegex: "(?:不|不会|不得|禁止)[^。；\\n]{0,12}(?:收取|要求)[^。；\\n]{0,12}(?:押金|保证金|服装费)|不扣押[^。；\\n]{0,10}(?:证件|身份证)",
      reason: "用人单位不得向劳动者收取押金、保证金等财物，也不得扣押居民身份证和其他证件。",
      action: "拒绝支付任何入职押金，保留招聘信息和付款记录，必要时向人社部门投诉。",
      lawIds: ["lcl_9", "lcl_26"]
    },
    {
      id: "training_loan",
      title: "培训贷或变相岗前收费",
      category: "招聘诈骗",
      severity: "high",
      weight: 24,
      confidence: 0.95,
      regex: "(?:培训贷|分期贷款|贷款培训|岗前培训费|先交[^。；\\n]{0,10}培训费|工作未满[^。；\\n]{0,12}偿还培训贷款)",
      exceptionRegex: "(?:不|不会|不得|禁止)[^。；\\n]{0,12}(?:要求|设置|收取)?[^。；\\n]{0,12}(?:培训贷|培训费|岗前收费)",
      reason: "以入职为条件要求求职者贷款或先缴纳高额培训费用，存在招聘诈骗和变相收费风险。",
      action: "立即停止付款和贷款，核验机构资质，保留聊天、合同、转账与宣传页面证据。",
      lawIds: ["lcl_9", "lcl_26"]
    },
    {
      id: "probation_salary",
      title: "试用期工资低于法定底线",
      category: "试用期",
      severity: "high",
      weight: 18,
      confidence: 0.88,
      regex: "试用期[^。；\\n]{0,18}(?:工资|薪资|薪酬)[^。；\\n]{0,15}(?:50%|60%|70%|不支付|零工资|无薪)",
      exceptionRegex: "不低于[^。；\\n]{0,8}80%|达到[^。；\\n]{0,8}80%|符合[^。；\\n]{0,8}80%",
      reason: "试用期工资不得低于本单位相同岗位最低档工资或合同约定工资的80%，且不得低于当地最低工资标准。",
      action: "要求写明试用期月工资，并对照合同约定工资和当地最低工资进行核验。",
      lawIds: ["lcl_20", "lcl_85"]
    },
    {
      id: "probation_duration",
      title: "试用期期限需要重点核验",
      category: "试用期",
      severity: "medium",
      weight: 11,
      confidence: 0.82,
      regex: "(?:试用期[^。；\\n]{0,12}(?:六个月|6个月|一年|十二个月|延长试用期)|(?:转正后|入职后)[^。；\\n]{0,12}再次试用)",
      exceptionRegex: "试用期[^。；\\n]{0,8}不超过(?:六个月|6个月)|(?:合同期限三年以上|三年以上固定期限|无固定期限)[^。；\\n]{0,30}试用期[^。；\\n]{0,10}(?:六个月|6个月)",
      reason: "六个月试用期只有在三年以上固定期限或无固定期限合同下才可能合法；同一单位只能约定一次试用期。",
      action: "核对劳动合同期限、试用期次数和转正条件，拒绝口头延长或不合理重复试用。",
      lawIds: ["lcl_19"]
    },
    {
      id: "noncompete_risk",
      title: "竞业限制期限或补偿异常",
      category: "离职限制",
      severity: "high",
      weight: 19,
      confidence: 0.91,
      regex: "竞业限制[^。；\\n]{0,35}(?:三年|3年|不支付(?:经济)?补偿|无需支付|无经济补偿)|离职后[^。；\\n]{0,12}(?:三年|3年)[^。；\\n]{0,15}不得",
      reason: "竞业限制期限不得超过二年；适用人员范围和补偿安排均有法定限制，不能任意扩大。",
      action: "核对岗位是否属于竞业限制适用人员，要求明确补偿标准、支付方式和限制范围。",
      lawIds: ["lcl_23_24"]
    },
    {
      id: "overtime_unpaid",
      title: "排除或变相规避加班费",
      category: "工时薪酬",
      severity: "high",
      weight: 18,
      confidence: 0.92,
      regex: "(?:996|自愿加班|无偿加班|不支付加班费|加班费[^。；\\n]{0,10}(?:包含|已包含)[^。；\\n]{0,8}工资|自愿放弃加班费)",
      reason: "加班安排和加班费支付属于法定义务，以“自愿”为名排除加班费责任存在违法风险。",
      action: "保存考勤、工作群、任务记录和工资单，要求明确工时制度和加班费计算方式。",
      lawIds: ["labor_41_44", "labor_50_wage", "lcl_85"]
    },
    {
      id: "resignation_penalty",
      title: "辞职违约金或不合理离职限制",
      category: "离职限制",
      severity: "high",
      weight: 18,
      confidence: 0.89,
      regex: "(?:辞职|离职|未满[^。；\\n]{0,6}年)[^。；\\n]{0,18}违约金|离职需[^。；\\n]{0,12}批准",
      reason: "除服务期和竞业限制等法定情形外，用人单位一般不得随意约定由劳动者承担违约金，也不能剥夺提前通知解除合同的权利。",
      action: "逐项核验违约金对应的法定情形和金额依据，保留提出离职的时间和送达证据。",
      lawIds: ["lcl_37", "lcl_26"]
    },
    {
      id: "unilateral_change",
      title: "单方调岗、调薪或变更工作地点",
      category: "合同变更",
      severity: "medium",
      weight: 12,
      confidence: 0.86,
      regex: "(?:公司|用人单位)[^。；\\n]{0,12}(?:随时|根据经营需要|无需同意)[^。；\\n]{0,16}(?:调岗|调薪|调整(?:岗位|薪酬|薪资|工作地点))|无条件服从[^。；\\n]{0,8}调岗",
      reason: "劳动合同变更原则上应协商一致并采用书面形式，完全排除劳动者协商权的条款存在风险。",
      action: "要求明确岗位、薪酬、工作地点和变更程序，保留原合同及调岗通知。",
      lawIds: ["lcl_35", "lcl_26"]
    },
    {
      id: "wage_delay",
      title: "工资延迟、押金式发放或离职结算异常",
      category: "工资支付",
      severity: "high",
      weight: 18,
      confidence: 0.90,
      regex: "押[^。；\\n]{0,4}个月工资|次月[^。；\\n]{0,4}(?:30|28|月底)[^。；\\n]{0,8}发放|年底[^。；\\n]{0,6}(?:统一|一次性)[^。；\\n]{0,4}发放|离职后[^。；\\n]{0,12}结算(?:剩余)?工资",
      reason: "工资应依法按月足额支付，无故拖欠或克扣工资存在法律责任。",
      action: "确认每月工资发放日期，保留工资条、银行流水和催款记录。",
      lawIds: ["labor_50_wage", "lcl_85"]
    },
    {
      id: "no_written_contract",
      title: "不签订或拖延签订书面劳动合同",
      category: "合同形式",
      severity: "high",
      weight: 17,
      confidence: 0.91,
      regex: "口头约定|暂不签订[^。；\\n]{0,10}劳动合同|转正后[^。；\\n]{0,8}(?:再|才)[^。；\\n]{0,6}签订|试用期不签合同",
      reason: "建立劳动关系后应依法订立书面劳动合同，超过一个月未订立存在二倍工资等风险。",
      action: "保留入职通知、考勤、工资发放和工作沟通记录，主动要求补签书面合同。",
      lawIds: ["lcl_10_82"]
    },
    {
      id: "social_base",
      title: "社保基数或缴纳方式异常",
      category: "社会保障",
      severity: "medium",
      weight: 11,
      confidence: 0.78,
      regex: "社保[^。；\\n]{0,15}(?:最低基数|按最低标准)|(?:按)?最低基数[^。；\\n]{0,10}(?:办理|缴纳)[^。；\\n]{0,6}社保|最低标准[^。；\\n]{0,10}(?:办理|缴纳)[^。；\\n]{0,6}社保|工资[^。；\\n]{0,12}另发[^。；\\n]{0,12}社保",
      reason: "社保缴费基数通常应与工资收入相关联，统一按最低基数或拆分工资规避缴费可能产生争议。",
      action: "核对工资构成、合同金额、社保缴费记录和缴费基数。",
      lawIds: ["social_58_60"]
    },
    {
      id: "discrimination",
      title: "婚育、性别等就业歧视风险",
      category: "平等就业",
      severity: "high",
      weight: 18,
      confidence: 0.94,
      regex: "(?:不得|禁止|承诺)[^。；\\n]{0,8}(?:怀孕|生育|结婚|婚育)|仅限男性|男性优先|女性[^。；\\n]{0,8}(?:未婚|未育)",
      reason: "与岗位无关的性别、婚育限制可能构成就业歧视。",
      action: "保存招聘页面和沟通记录，可向人社部门、工会或公共法律服务平台反映。",
      lawIds: ["employment_27"]
},
    {
      id: "internship_wage_forfeit",
      title: "离职即扣发实习补贴",
      category: "工资支付",
      severity: "high",
      weight: 30,
      confidence: 0.98,
      regex: "(?:离职|自动离职)[^。；\\n]{0,35}(?:工资|补贴)[^。；\\n]{0,15}(?:不予|不|停发|扣除|核发)|(?:入职后|实习)[^。；\\n]{0,25}(?:10|十|15|十五)[^。；\\n]{0,12}个?工作日[^。；\\n]{0,25}(?:离职|自动离职)",
      reason: "以离职为条件不支付已经提供劳动的实习补贴或工资，属于惩罚性扣发，需重点核实其法律性质。",
      action: "要求删除离职限制；保留考勤、工作记录和补贴发放记录，明确离职时按实际出勤结算。",
      lawIds: ["wage_payment_9_15", "labor_50_wage", "civil_code_contract"],
      documentTypes: ["实习协议"]
    },
    {
      id: "third_party_payor",
      title: "签约单位、实际用工单位和发薪主体不一致",
      category: "用工关系",
      severity: "high",
      weight: 18,
      confidence: 0.91,
      regex: "(?:委托|由)[^。；\\n]{0,70}(?:分公司|第三方|人力资源|人才)[^。；\\n]{0,45}(?:发放|支付|代发|薪酬|工资)",
      reason: "签约、实际用工和发薪主体分离会使用人责任和证据指向不清，也可能涉及派遣、外包或事实用工。",
      action: "书面确认实际用工单位、发薪主体、管理主体和事故责任主体，并保留排班、考勤和发薪记录。",
      lawIds: ["labor_relationship_notice", "internship_policy", "lcl_26"],
      documentTypes: ["实习协议", "劳务协议"]
    },
    {
      id: "overtime_without_compensation",
      title: "安排加班但未约定补偿",
      category: "工时薪酬",
      severity: "medium",
      weight: 14,
      confidence: 0.86,
      regex: "(?:安排|要求|需要)[^。；\\n]{0,24}(?:延长工作时间|休息日|节假日)[^。；\\n]{0,24}加班",
      exceptionRegex: "加班费|加班工资|调休|补休|加班补偿",
      reason: "协议允许安排加班但没有明确加班报酬、调休或审批程序，实际执行容易产生争议。",
      action: "要求补充加班审批、加班费或调休规则，并保存考勤、排班和任务分配记录。",
      lawIds: ["labor_41_44", "labor_50_wage"],
      documentTypes: ["实习协议", "劳动合同"]
    },
    {
      id: "performance_unilateral",
      title: "绩效津贴可单方变化",
      category: "工资支付",
      severity: "medium",
      weight: 12,
      confidence: 0.84,
      regex: "绩效[^。；\\n]{0,30}(?:随|根据)[^。；\\n]{0,28}(?:岗位|表现)[^。；\\n]{0,24}(?:调整|变化)|绩效[^。；\\n]{0,35}(?:理解|确认|接受)",
      reason: "绩效津贴调整缺少明确标准、计算方式和异议程序，存在变相降低报酬的空间。",
      action: "要求写明绩效基数、考核周期、计算方式和调整程序，并保留工资条。",
      lawIds: ["civil_code_contract", "lcl_35"],
      documentTypes: ["实习协议", "劳动合同"]
    },
    {
      id: "broad_deduction",
      title: "工资扣款范围不明确",
      category: "工资支付",
      severity: "medium",
      weight: 13,
      confidence: 0.87,
      regex: "扣除[^。；\\n]{0,15}(?:有关|其他|相应|相关|适当)[^。；\\n]{0,12}(?:款项|费用)|代缴[^。；\\n]{0,25}扣除",
      reason: "“有关款项”“其他费用”等表述范围不清，可能造成未经明确依据的工资扣减。",
      action: "要求逐项列明可扣除项目、法律依据、计算方式和通知程序。",
      lawIds: ["wage_payment_9_15", "labor_50_wage"],
      documentTypes: ["实习协议", "劳动合同"]
    },
    {
      id: "confidentiality_overbroad",
      title: "保密义务范围过宽或期限过长",
      category: "保密与竞业",
      severity: "medium",
      weight: 14,
      confidence: 0.86,
      regex: "保密[^。；\\n]{0,18}(?:最高限度|所有|不明确|视为商业机密)|保密(?:期限|义务)[^。；\\n]{0,25}(?:终止|解除|结束)[^。；\\n]{0,18}(?:后|继续有效)|视为商业机密",
      reason: "将不明确信息推定为商业秘密、无限期保密或让员工承担全部损失，可能导致义务边界不清。",
      action: "要求限定商业秘密范围、保密期限、例外情形和责任上限，并保留信息和权限记录。",
      lawIds: ["civil_code_contract", "lcl_23_24"],
      documentTypes: ["实习协议", "劳动合同"]
    },
    {
      id: "unilateral_termination",
      title: "单方解除且不支付补偿",
      category: "解除与终止",
      severity: "high",
      weight: 20,
      confidence: 0.9,
      regex: "(?:有权|可以)[^。；\\n]{0,20}(?:立即|随时|单方)[^。；\\n]{0,12}解除[^。；\\n]{0,24}(?:不支付|无需支付|不予支付)[^。；\\n]{0,10}(?:赔偿金|补偿)",
      reason: "协议赋予一方过宽的单方解除权并排除补偿，需结合实际解除理由和法定程序判断。",
      action: "要求列明解除条件、通知程序、证据要求和补偿规则，并保留解除通知与沟通记录。",
      lawIds: ["lcl_26", "lcl_38_46_47"],
      documentTypes: ["实习协议", "劳动合同"]
    },
    {
      id: "internship_insurance_missing",
      title: "缺少实习责任或意外伤害保险安排",
      category: "实习保障",
      severity: "medium",
      weight: 13,
      confidence: 0.78,
      factOnly: true,
      regex: "劳动保护|安全卫生|防护用品|实习期间",
      exceptionRegex: "意外|工伤|保险|实习责任|商业保险",
      reason: "实习协议提到劳动保护但没有看到实习责任保险或意外伤害保障安排，发生事故时责任和救治路径不清。",
      action: "要求补充保险类型、投保主体、保额、理赔流程和事故联系人。",
      lawIds: ["internship_policy"],
      documentTypes: ["实习协议"]
    },
    {
      id: "internship_relationship_mismatch",
      title: "名为实习但存在劳动用工特征",
      category: "用工关系",
      severity: "high",
      weight: 19,
      confidence: 0.84,
      factOnly: true,
      regex: "标准工时|实际出勤|绩效|考勤|派驻",
      reason: "协议同时出现固定期限、标准工时、实际出勤、绩效或派驻等特征，需结合实际管理、报酬和学校安排判断是否可能构成劳动关系或派遣用工。",
      action: "补充学校实习安排、三方协议、考勤与报酬记录，并请专业人员判断关系性质。",
      lawIds: ["labor_relationship_notice", "internship_policy", "lcl_26"],
      documentTypes: ["实习协议"]
},
    {
      id: "tripartite_not_labor_contract",
      title: "以三方协议代替劳动合同",
      category: "合同性质",
      severity: "high",
      weight: 18,
      confidence: 0.93,
      regex: "三方协议[^。；\\n]{0,30}(?:代替|替代|视为|等同)[^。；\\n]{0,15}劳动合同|以三方协议[^。；\\n]{0,15}为准",
      reason: "三方协议主要确认就业意向和报到安排，不能替代入职后的书面劳动合同；劳动关系建立后仍需依法订立劳动合同。",
      action: "要求明确三方协议与劳动合同的关系，并在入职后一个月内签订书面劳动合同。",
      lawIds: ["tripartite_policy", "lcl_10_82", "labor_relationship_notice"],
      documentTypes: ["三方协议"]
    },
    {
      id: "tripartite_penalty_overbroad",
      title: "三方协议违约金过高或依据不清",
      category: "违约责任",
      severity: "medium",
      weight: 16,
      confidence: 0.88,
      regex: "违约金[^。；\\n]{0,24}(?:\\d{3,}|[一二三四五六七八九十百千万]{2,})|未满[^。；\\n]{0,12}(?:服务期|年限)[^。；\\n]{0,20}违约金|违约[^。；\\n]{0,15}(?:赔偿|违约金)",
      reason: "三方协议可以约定违约责任，但高额违约金、没有服务期或培训成本依据的违约金，实际执行时可能被调整。",
      action: "要求写明违约金计算依据、服务期、培训费用和实际损失，并保留沟通记录。",
      lawIds: ["tripartite_policy", "civil_code_contract", "lcl_26"],
      documentTypes: ["三方协议"]
    },
    {
      id: "tripartite_blank_terms",
      title: "三方协议关键条款空白或待定",
      category: "条款完整性",
      severity: "medium",
      weight: 14,
      confidence: 0.87,
      regex: "(?:岗位|职位|薪资|工资|试用期|工作地点|报到时间|服务期)[^。；\\n]{0,18}(?:空白|待定|面议|另行约定|以实际为准|未填写|不填)",
      reason: "岗位、薪资、试用期、工作地点或报到时间不明确，后续容易产生争议，也无法据此判断就业条件。",
      action: "要求在签署前补齐岗位、薪资、试用期、工作地点、报到时间和违约责任。",
      lawIds: ["tripartite_policy", "civil_code_contract"],
      documentTypes: ["三方协议"]
    },
    {
      id: "tripartite_entity_mismatch",
      title: "签约单位与报到或实际用工单位不一致",
      category: "主体一致性",
      severity: "medium",
      weight: 15,
      confidence: 0.86,
      regex: "(?:签约单位|甲方)[^。；\\n]{0,35}(?:与)?[^。；\\n]{0,20}(?:报到单位|接收单位|实际用工单位)[^。；\\n]{0,20}(?:不一致|不同)|(?:报到单位|接收单位)[^。；\\n]{0,20}(?:不是|非)[^。；\\n]{0,20}(?:甲方|签约单位)",
      reason: "签约主体、报到单位和实际用工单位不一致，会影响档案接收、报到、社保和事故责任归属。",
      action: "书面确认签约主体、报到单位、实际用工单位和档案接收单位，并保留三方盖章文本。",
      lawIds: ["tripartite_policy", "labor_relationship_notice", "civil_code_contract"],
      documentTypes: ["三方协议"]
    },
    {
      id: "tripartite_school_missing",
      title: "三方协议缺少学校签章",
      category: "协议形式",
      severity: "medium",
      weight: 12,
      confidence: 0.82,
      factOnly: true,
      regex: "丙方|学校",
      reason: "三方协议通常需要毕业生、学校和用人单位三方确认；学校未签章会影响报到、档案和就业手续办理。",
      action: "补齐学校就业部门盖章、经办人和日期，并保留学校审核记录。",
      lawIds: ["tripartite_policy"],
      documentTypes: ["三方协议"]
    },
    {
      id: "tripartite_archive_household",
      title: "档案、户口或报到证安排不清",
      category: "就业手续",
      severity: "medium",
      weight: 13,
      confidence: 0.85,
      regex: "(?:档案|户口|户籍|报到证)[^。；\\n]{0,24}(?:自行|不负责|待定|空白|转回原籍|不接收|无处接收)",
      reason: "档案、户口和报到证安排不清会影响毕业派遣、入职手续和后续公共服务办理。",
      action: "要求写明档案接收单位、地址、联系人，户口迁移方向和报到证抬头，并向学校就业部门确认。",
      lawIds: ["tripartite_policy"],
      documentTypes: ["三方协议"]
    },
    {
      id: "tripartite_service_period",
      title: "服务期或培训费与违约金绑定",
      category: "违约责任",
      severity: "medium",
      weight: 14,
      confidence: 0.84,
      regex: "服务期[^。；\\n]{0,25}(?:违约金|赔偿|服务年限)|培训费[^。；\\n]{0,25}(?:违约金|赔偿|服务期)",
      reason: "服务期和培训费违约条款需要明确培训内容、费用凭证、服务期限和违约金计算方式，否则容易产生争议。",
      action: "要求列明培训项目、费用明细、服务期起算和违约金上限，并保留培训协议和付款凭证。",
      lawIds: ["tripartite_policy", "civil_code_contract", "lcl_26"],
      documentTypes: ["三方协议"]
    }
  ],

  demoCases: [
    {
      id: "case_high_001",
      title: "新媒体运营劳动合同",
      company: "某成长型科技公司",
      role: "新媒体运营",
      type: "劳动合同",
      riskPreview: 92,
      text: `某成长型科技公司劳动合同（演示文本）\n\n甲方：某成长型科技有限公司\n乙方：张同学\n\n一、合同期限\n本合同期限为一年，自2026年10月8日起。试用期三个月，试用期工资为转正工资的60%。\n\n二、社会保险\n乙方自愿放弃社会保险，甲方每月额外发放500元社保补贴。乙方不得再以未缴社保为由主张任何权利。\n\n三、入职费用\n为保证乙方履约，入职时需缴纳设备押金2000元。甲方提供岗前培训，培训费用可通过合作分期贷款支付，工作满一年后由甲方承担。\n\n四、工作时间\n乙方接受公司安排的弹性工作制，因工作需要延长工作时间的，视为乙方自愿加班，不支付加班费。\n\n五、岗位调整\n甲方可根据经营需要随时调整乙方岗位、薪资及工作地点，乙方应无条件服从。\n\n六、离职与竞业\n乙方辞职需提前三个月申请并经公司批准，未满一年离职需支付违约金10000元。离职后三年内不得从事同类业务，公司无需另行支付竞业限制补偿。\n\n七、工资发放\n实行押一个月工资制度，每月工资于次月30日前发放。离职后满两个月再结算剩余工资。`
    },
    {
      id: "case_intern_002",
      title: "人才服务公司派驻实习协议",
      company: "某人才服务集团（派驻深圳）",
      role: "测试实习生",
      type: "实习协议",
      riskPreview: 96,
      text: `实习协议（脱敏演示文本）\n\n某人才服务有限公司（以下简称“甲方”），同意 示例学院 学校学生 张某，在甲方实习。\n\n第一条 乙方自 2026 年 6 月 16 日至 2026 年 12 月 15 日，被派驻至深圳市某科技有限公司，在测试部门实习，具体实习内容另行规定。\n\n第二条 乙方的工作时间执行标准工时制。\n\n第三条 甲方因生产（工作）需要，可依法安排乙方延长工作时间、休息日或节假日加班。\n\n第五条 乙方按实际出勤日计薪，实习补贴为 140 元/天。乙方绩效津贴随工作岗位调整和工作表现变化。甲方委托其依法设立的某人才服务有限公司湘江新区分公司作为薪酬发放主体，按月发放实习补贴。承诺入职后 10 个工作日内不会自动离职，如离职则工资不予核发。\n\n第六条 甲方支付乙方的劳动报酬为税前收入，乙方同意甲方有权根据规定扣除有关款项并代缴。\n\n第九条 乙方应对在甲方实习期间所掌握的所有甲方认为具有保密性质的信息进行最高限度的保密，在本协议终止后继续有效。\n\n第十二条 乙方违反本协议规定的，甲方有权立即解除劳动合同并不支付赔偿金。`
    },
    {
      id: "case_tripartite_003",
      title: "高校毕业生三方协议",
      company: "深圳某科技有限公司",
      role: "测试工程师",
      type: "三方协议",
      riskPreview: 96,
      text: `全国普通高等学校毕业生就业协议书（三方协议）\n\n甲方（用人单位）名称：深圳某科技有限公司\n乙方（毕业生）姓名：张某\n丙方（学校）名称：示例学院\n\n第一条 乙方到甲方报到时间为2026年7月1日，工作地点为深圳市南山区，岗位为测试工程师。\n第二条 试用期六个月，月工资5000元，岗位职责另行约定，薪资以实际发放为准。\n第三条 甲方有权根据经营需要调整岗位；乙方未满服务期离职的，应支付违约金20000元。\n第四条 甲方不负责档案和户口接收，档案转回原籍，户口自行处理。\n第五条 本三方协议代替劳动合同，双方以本协议为准。\n甲方（盖章）： 乙方（签字）： 丙方（学校）（盖章）：`
    },
    {
      id: "case_safe_003",
      title: "规范劳动合同样例",
      company: "某合规企业",
      role: "数据分析师",
      type: "劳动合同",
      riskPreview: 8,
      text: `某合规企业劳动合同（演示文本）\n\n1. 合同期限三年，试用期三个月，试用期工资为约定工资的85%，且不低于当地最低工资标准。\n2. 公司自用工之日起依法为员工缴纳社会保险和住房公积金。\n3. 加班按照国家规定安排并依法支付加班费或安排调休。\n4. 岗位、薪酬和工作地点变更由双方协商一致后书面确认。\n5. 员工提前三十日书面通知可以解除劳动合同，试用期提前三日通知。\n6. 工资于每月十五日前以货币形式足额支付。`
    }
  ],

  evaluationCases: [
    { id: "eval_01", title: "放弃社保", text: "员工自愿放弃社会保险，公司每月发放社保补贴。", expected: ["no_social_insurance"] },
    { id: "eval_02", title: "入职押金", text: "新员工入职需缴纳2000元设备保证金。", expected: ["employment_deposit"] },
    { id: "eval_03", title: "培训贷", text: "求职者需通过分期贷款支付岗前培训费。", expected: ["training_loan"] },
    { id: "eval_04", title: "试用期工资", text: "试用期工资为转正工资的60%。", expected: ["probation_salary"] },
    { id: "eval_05", title: "三年竞业限制", text: "离职后三年内不得从事同类业务，公司无需支付补偿。", expected: ["noncompete_risk"] },
    { id: "eval_06", title: "无偿加班", text: "因工作需要延长工作时间，视为员工自愿加班，不支付加班费。", expected: ["overtime_unpaid"] },
    { id: "eval_07", title: "辞职违约金", text: "员工未满一年辞职需支付违约金10000元。", expected: ["resignation_penalty"] },
    { id: "eval_08", title: "单方调岗", text: "公司可根据经营需要随时调岗调薪，员工应无条件服从。", expected: ["unilateral_change"] },
    { id: "eval_09", title: "拖延书面合同", text: "试用期不签合同，转正后再签订劳动合同。", expected: ["no_written_contract"] },
    { id: "eval_10", title: "婚育歧视", text: "仅限男性，女性入职需承诺三年内不怀孕。", expected: ["discrimination"] }
  ],

  regionalPolicyPortals: {
    "全国": { authority: "人力资源和社会保障部", url: "https://www.mohrss.gov.cn/" },
    "北京": { authority: "北京市人力资源和社会保障局", url: "https://rsj.beijing.gov.cn/" },
    "上海": { authority: "上海市人力资源和社会保障局", url: "https://rsj.sh.gov.cn/" },
    "广东": { authority: "广东省人力资源和社会保障厅", url: "https://hrss.gd.gov.cn/" },
    "重庆": { authority: "重庆市人力资源和社会保障局", url: "https://rlsbj.cq.gov.cn/" },
    "四川": { authority: "四川省人力资源和社会保障厅", url: "https://rst.sc.gov.cn/" },
    "贵州": { authority: "贵州省人力资源和社会保障厅", url: "https://rst.guizhou.gov.cn/" },
    "云南": { authority: "云南省人力资源和社会保障厅", url: "https://hrss.yn.gov.cn/" },
    "陕西": { authority: "陕西省人力资源和社会保障厅", url: "https://hrss.shaanxi.gov.cn/" },
    "湖北": { authority: "湖北省人力资源和社会保障厅", url: "https://rst.hubei.gov.cn/" },
    "湖南": { authority: "湖南省人力资源和社会保障厅", url: "https://rst.hunan.gov.cn/" },
    "广西": { authority: "广西壮族自治区人力资源和社会保障厅", url: "https://rst.gxzf.gov.cn/" }
  },

  policyCatalog: [
    {
      id: "job_seeking_subsidy",
      title: "一次性求职创业补贴",
      authority: "人力资源和社会保障部门、财政部门",
      level: "国家政策框架",
      targetUsers: ["在校生", "应届毕业生", "毕业两年内未就业青年"],
      needs: ["求职", "困难帮扶"],
      support: "符合条件的毕业生可申请一次性求职创业补贴，具体对象和标准由各地执行。",
      conditions: ["通常面向低保家庭、零就业家庭、脱贫家庭、残疾及获得国家助学贷款等毕业生", "各地困难身份认定范围可能不同"],
      materials: ["身份证明", "毕业证明或学生证明", "困难身份或助学贷款证明", "当地要求的申请表"],
      channel: "所在高校就业部门或属地人社部门公共就业服务机构",
      sourceUrl: "https://www.mohrss.gov.cn/",
      status: "地方标准待核验"
    },
    {
      id: "internship_subsidy",
      title: "就业见习补贴",
      authority: "人力资源和社会保障部门、财政部门",
      level: "国家政策框架",
      targetUsers: ["应届毕业生", "毕业两年内未就业青年"],
      needs: ["见习", "积累经验"],
      support: "参加就业见习的人员和见习单位可按规定享受见习补贴及相关支持。",
      conditions: ["通常要求参加经认定的就业见习计划", "见习期限、补贴标准和对象由地方规定"],
      materials: ["毕业证明", "就业见习协议", "见习单位和考勤材料", "当地要求的申请表"],
      channel: "属地人社部门就业见习经办机构",
      sourceUrl: "https://www.mohrss.gov.cn/",
      status: "地方标准待核验"
    },
    {
      id: "social_insurance_subsidy",
      title: "社会保险补贴",
      authority: "人力资源和社会保障部门、财政部门",
      level: "国家政策框架",
      targetUsers: ["灵活就业人员", "毕业两年内未就业青年", "就业困难人员"],
      needs: ["社保", "减轻缴费负担"],
      support: "符合条件的高校毕业生和就业困难人员灵活就业后，可按规定申请社会保险补贴。",
      conditions: ["通常要求完成就业登记并以灵活就业身份缴纳社会保险费", "补贴期限和比例由地方规定"],
      materials: ["身份证", "就业创业证或就业登记材料", "社会保险缴费记录", "申请表"],
      channel: "属地人社部门或街道社区公共就业服务机构",
      sourceUrl: "https://www.mohrss.gov.cn/",
      status: "地方标准待核验"
    },
    {
      id: "training_subsidy",
      title: "职业技能培训补贴",
      authority: "人力资源和社会保障部门、财政部门",
      level: "国家政策框架",
      targetUsers: ["在校生", "应届毕业生", "毕业两年内未就业青年", "灵活就业人员"],
      needs: ["培训", "技能提升"],
      support: "参加纳入目录的职业技能培训并取得相应证书，可按规定申请培训补贴。",
      conditions: ["培训项目和证书需在补贴目录内", "补贴标准、次数和申请期限由地方规定"],
      materials: ["身份证明", "培训合格证或职业技能等级证书", "培训缴费凭证", "申请表"],
      channel: "属地人社部门职业培训经办机构",
      sourceUrl: "https://www.mohrss.gov.cn/",
      status: "地方标准待核验"
    },
    {
      id: "startup_loan",
      title: "创业担保贷款",
      authority: "人力资源和社会保障部门、财政部门、金融机构",
      level: "国家政策框架",
      targetUsers: ["应届毕业生", "毕业两年内未就业青年", "创业者"],
      needs: ["创业", "融资"],
      support: "符合条件的高校毕业生创业可申请创业担保贷款，并按地方规定享受贴息支持。",
      conditions: ["通常要求创业主体登记和经营场所材料", "贷款额度、期限、担保方式和贴息标准由地方规定"],
      materials: ["身份证明", "营业执照或创业项目材料", "经营场所证明", "贷款和担保申请材料"],
      channel: "属地人社部门创业服务机构或合作银行",
      sourceUrl: "https://www.mof.gov.cn/",
      status: "地方标准待核验"
    },
    {
      id: "startup_subsidy",
      title: "一次性创业补贴",
      authority: "人力资源和社会保障部门、财政部门",
      level: "国家政策框架",
      targetUsers: ["应届毕业生", "毕业两年内未就业青年", "创业者"],
      needs: ["创业", "创业补贴"],
      support: "首次创业且正常经营达到规定期限的高校毕业生，可按规定申请一次性创业补贴。",
      conditions: ["通常要求首次创业并办理登记", "持续经营期限和补贴金额由地方规定"],
      materials: ["身份证明", "营业执照", "经营流水或纳税材料", "申请表"],
      channel: "属地人社部门创业服务窗口",
      sourceUrl: "https://www.mohrss.gov.cn/",
      status: "地方标准待核验"
    },
    {
      id: "public_welfare_post",
      title: "公益性岗位补贴",
      authority: "人力资源和社会保障部门、财政部门",
      level: "国家政策框架",
      targetUsers: ["就业困难人员", "毕业两年内未就业青年"],
      needs: ["兜底就业", "困难帮扶"],
      support: "通过公益性岗位安置的就业困难人员可按规定享受岗位补贴和社会保险补贴。",
      conditions: ["需经就业困难人员认定和公益性岗位安置程序", "岗位范围和补贴标准由地方规定"],
      materials: ["就业困难人员认定材料", "公益性岗位安置协议", "考勤和工资材料", "申请表"],
      channel: "属地人社部门或街道社区公共就业服务机构",
      sourceUrl: "https://www.mohrss.gov.cn/",
      status: "地方标准待核验"
    },
    {
      id: "grassroots_compensation",
      title: "基层就业学费补偿或助学贷款代偿",
      authority: "教育、财政和就业主管部门",
      level: "国家政策框架",
      targetUsers: ["应届毕业生"],
      needs: ["基层就业", "学费补偿"],
      support: "符合条件的毕业生到中西部地区、艰苦边远地区和基层单位就业，可按规定申请学费补偿或助学贷款代偿。",
      conditions: ["就业地区、单位性质和服务年限必须符合政策要求", "具体范围由国家和地方文件规定"],
      materials: ["毕业证明", "就业协议或劳动合同", "服务年限证明", "学费或助学贷款材料"],
      channel: "所在高校学生资助或就业管理部门",
      sourceUrl: "https://www.moe.gov.cn/",
      status: "地方标准待核验"
    },
    {
      id: "public_employment_service",
      title: "高校毕业生公共就业服务",
      authority: "各级人力资源和社会保障部门",
      level: "国家政策框架",
      targetUsers: ["在校生", "应届毕业生", "毕业两年内未就业青年", "灵活就业人员"],
      needs: ["求职", "岗位推荐", "政策咨询", "就业指导"],
      support: "公共就业服务机构提供求职登记、岗位推荐、职业指导、政策咨询和就业援助等服务。",
      conditions: ["面向高校毕业生等劳动者开放", "部分专项服务需要完成求职或就业登记"],
      materials: ["身份证明", "求职登记信息", "学历或技能信息"],
      channel: "属地公共就业服务机构、人社服务窗口或线上就业服务平台",
      sourceUrl: "https://www.mohrss.gov.cn/",
      status: "全国服务框架"
    },
    {
      id: "labor_rights_support",
      title: "劳动权益咨询与法律援助",
      authority: "人力资源和社会保障、司法行政、工会和法律援助机构",
      level: "国家政策框架",
      targetUsers: ["在校生", "应届毕业生", "毕业两年内未就业青年", "灵活就业人员"],
      needs: ["维权", "法律援助", "劳动仲裁"],
      support: "劳动者可以就欠薪、未缴社保、违法解除等问题向劳动保障监察、仲裁、工会或公共法律服务渠道咨询和申请援助。",
      conditions: ["部分法律援助需要符合经济困难或特定案件条件", "劳动仲裁和监察受理范围按法律规定执行"],
      materials: ["身份证明", "劳动合同或用工证明", "工资和考勤记录", "沟通记录", "其他证据材料"],
      channel: "属地劳动保障监察机构、劳动人事争议仲裁委员会、工会或公共法律服务中心",
      sourceUrl: "https://www.moj.gov.cn/",
      status: "全国服务框架"
    },
    {
      id: "flexible_employment_rights",
      title: "新就业形态劳动者权益保障",
      authority: "人力资源和社会保障部门及相关部门",
      level: "国家政策框架",
      targetUsers: ["灵活就业人员", "新就业形态劳动者"],
      needs: ["灵活就业", "社保", "职业伤害保障", "维权"],
      support: "平台经济和灵活就业人员可关注职业伤害保障、社保参保、劳动报酬和算法规则透明等权益保障政策。",
      conditions: ["不同用工关系的权利义务不同", "具体参保和保障办法由地方及行业政策确定"],
      materials: ["平台用工协议", "订单和收入记录", "平台沟通记录", "身份证明"],
      channel: "属地人社部门新就业形态服务窗口、工会和公共法律服务机构",
      sourceUrl: "https://www.mohrss.gov.cn/",
      status: "国家政策框架，地方细则不同"
    },
    {
      id: "employment_priority_policy",
      title: "就业优先战略与高质量充分就业政策",
      authority: "党中央、国务院及各级就业主管部门",
      level: "国家战略方向",
      targetUsers: ["在校生", "应届毕业生", "毕业两年内未就业青年", "灵活就业人员", "创业者"],
      needs: ["求职", "创业", "培训", "困难帮扶"],
      support: "国家将高质量充分就业作为经济社会发展优先目标，支持高校毕业生等青年就业创业，完善公共就业服务和重点群体就业支持。",
      conditions: ["具体支持以各部门和地方配套政策为准", "本条目用于说明政策方向，不作为具体补贴依据"],
      materials: ["根据具体配套政策确定"],
      channel: "各级人社部门、教育部门和公共就业服务机构",
      sourceUrl: "https://www.gov.cn/",
      status: "国家战略方向"
    }
  ],

  evidenceChecklist: [
    { id: "offer", label: "招聘广告或 Offer 原件", done: true, level: "核心" },
    { id: "contract", label: "劳动合同或实习协议", done: true, level: "核心" },
    { id: "chat", label: "与 HR、主管的聊天记录", done: true, level: "核心" },
    { id: "attendance", label: "考勤、排班或工作群记录", done: false, level: "重要" },
    { id: "salary", label: "工资条、银行流水或转账记录", done: false, level: "核心" },
    { id: "work", label: "工作成果、邮件和任务记录", done: false, level: "重要" },
    { id: "notice", label: "调岗、降薪、离职通知", done: false, level: "重要" },
    { id: "record", label: "沟通录音及文字整理", done: false, level: "可选" }
  ],

  timeline: [
    { date: "2026-09-18", title: "收到招聘信息", detail: "通过招聘平台收到面试邀约并保存原始页面。" },
    { date: "2026-09-24", title: "收到 Offer", detail: "Offer 写明试用期工资为转正工资的60%。" },
    { date: "2026-09-28", title: "收到合同草稿", detail: "合同包含放弃社保、设备押金和三年竞业限制。" },
    { date: "2026-09-30", title: "发起风险研判", detail: "系统识别 9 项风险，其中 7 项为高风险。" }
  ],

  evaluationSummary: {
    regression: {
      dataset: "80条开发回归集",
      precision: 0.9811,
      recall: 1,
      f1: 0.9905,
      exactMatch: 0.9875,
      abstentionRecall: 1,
      independent: false,
      note: "参与规则开发，仅用于功能回归，不能作为真实用户准确率。"
    },
    frozen: {
      dataset: "40条冻结留出集",
      precision: 1,
      recall: 0.2692,
      f1: 0.4242,
      exactMatch: 0.525,
      abstentionRecall: 0.8333,
      independent: true,
      note: "规则开发后创建，未根据结果调规则，用于展示纯规则链的真实泛化边界。"
    }
  },

  semanticPatterns: {
    no_social_insurance: "(?=.*(?:社保|社会保险))(?=.*(?:员工自行|自行购买|公司不承担|不办理|不缴|再补缴|自行承担)).*",
    employment_deposit: "(?=.*(?:押金|保证金|工装费|服装费|毕业证原件|证件原件|身份证原件))(?=.*(?:入职|录用|先交|需交|须交|上交|收取|保管|缴纳)).*",
    training_loan: "(?=.*(?:贷款|培训费|培训收费|技能提升))(?=.*(?:入职|岗前|岗位|办理|分期|工资中扣除|先交|为获得)).*",
    probation_salary: "(?:试用期[^。；\\n]{0,22}(?:[1-7][0-9]%|一半|低于[^。；\\n]{0,6}80%)|前(?:一|二|三|1|2|3)个月[^。；\\n]{0,18}(?:一半|只发|仅发|不给)).*",
    probation_duration: "(?:(?:试用期|实习期)[^。；\\n]{0,16}(?:[7-9]个月|1[0-2]个月|八个月|九个月|十个月|十一个月|十二个月|一年)|(?:劳动合同|合同期限|期限)[^。；\\n]{0,14}(?:一年|两年|二年|1年|2年)[^。；\\n]{0,18}试用期[^。；\\n]{0,8}(?:[3-9]个月|1[0-2]个月)).*",
    noncompete_risk: "(?=.*(?:竞业禁止|竞业限制|不得同业|不得从事同类))(?=.*(?:三年|3年|24个月|无补偿|未约定[^。；\\n]{0,8}补偿|不支付[^。；\\n]{0,8}补偿)).*",
    overtime_unpaid: "(?=.*(?:加班|额外工时|延长工作时间))(?=.*(?:不计算|不结算|不支付|已覆盖|不再结算|视为自愿|不得主张)).*",
    resignation_penalty: "(?=.*(?:离职|辞职|服务期))(?=.*(?:赔偿|违约金|须经[^。；\\n]{0,8}同意|未完成|扣发)).*",
    unilateral_change: "(?=.*(?:调岗|调薪|调整[^。；\\n]{0,8}(?:岗位|薪资|薪酬)|工作地点[^。；\\n]{0,8}变更))(?=.*(?:公司有权|无需同意|不得异议|根据[^。；\\n]{0,8}业务|依[^。；\\n]{0,8}业务)).*",
    wage_delay: "(?=.*(?:工资|报酬))(?=.*(?:推迟|下月底|三个月后|再发放|延后|延期)).*",
    no_written_contract: "(?=.*(?:书面合同|劳动合同|书面文件))(?=.*(?:代替|再签|后再签|满[^。；\\n]{0,8}再签|未签|暂不签)).*",
    social_base: "(?=.*(?:社保|社会保险))(?=.*(?:最低档|最低基数|按基本工资|不含绩效|不按实际工资)).*",
    discrimination: "(?:未婚女性|已婚未育|不生育|生育承诺|承诺[^。；\\n]{0,8}(?:不怀孕|不生育)|仅限男性|男性优先).*"
  },

  reviewRules: [
    {
      id: "relationship_ambiguity",
      regex: "实习|兼职|劳务|非全日制|灵活用工|项目合作|合作人员|合作协议",
      title: "劳动关系性质需核实",
      detail: "实习、兼职、劳务或非全日制关系适用规则不同，需要结合实际管理方式、报酬和用工事实判断。"
    },
    {
      id: "missing_terms",
      regex: "工资面议|薪资面议|社保面议|试用期待定|合同期限未定|以实际为准|另行约定|尚未确定|尚未明确|未确定|未明确",
      title: "关键条款缺失或表述不确定",
      detail: "工资、试用期、社保或合同期限未明确，不能仅凭当前材料输出确定结论。"
    },
    {
      id: "oral_context",
      regex: "口头承诺|微信里说|HR口头表示|暂未写入合同",
      title: "口头约定需要补充证据",
      detail: "未写入书面材料的口头承诺需要聊天、录音、邮件或其他证据佐证。"
    }
  ],

  jurisdictionProfiles: [
    {
          "id": "全国规则",
          "title": "全国基础规则包",
          "scope": "全国",
          "status": "基础模式",
          "note": "全国性法律法规和规则；地方金额与条件需选择具体地区后核验。",
          "source": "全国人大法律法规数据库、人力资源和社会保障部",
          "version": "2026-10",
          "officialUrl": "https://www.mohrss.gov.cn/",
          "effectiveDate": ""
    },
    {
          "id": "北京",
          "title": "北京地区政策适配包",
          "scope": "北京",
          "status": "最低工资已核验",
          "note": "2025年9月1日起：月最低工资2540元，非全日制小时最低工资27.7元。",
          "source": "北京市人力资源和社会保障局",
          "version": "2025-09-01",
          "officialUrl": "https://rsj.beijing.gov.cn/weimenhu/wmtgz/202507/t20250724_4157298.html",
          "effectiveDate": "2025-09-01"
    },
    {
          "id": "上海",
          "title": "上海地区政策适配包",
          "scope": "上海",
          "status": "最低工资已核验",
          "note": "2025年7月1日起：月最低工资2740元，小时最低工资25元。",
          "source": "上海市人力资源和社会保障局",
          "version": "2025-07-01",
          "officialUrl": "https://rsj.sh.gov.cn/tgzfl_17732/20250714/t0035_1434097.html",
          "effectiveDate": "2025-07-01"
    },
    {
          "id": "广东",
          "title": "广东地区政策适配包",
          "scope": "广东",
          "status": "最低工资已核验",
          "note": "2026年9月1日起：月最低工资分档2680、2300、2040元；小时最低工资分档25.4、21.9、20.2元。广州执行2680元/月，深圳单列2700元/月。",
          "source": "广东省人力资源和社会保障厅",
          "version": "2026-09-01",
          "officialUrl": "https://hrss.gd.gov.cn/zwgk/xxgkml/gzdt/content/post_4942224.html",
          "effectiveDate": "2026-09-01"
    },
    {
          "id": "深圳",
          "title": "深圳地区政策适配包",
          "scope": "深圳",
          "status": "最低工资已核验",
          "note": "2026年9月1日起：全日制月最低工资2700元，非全日制小时最低工资25.4元。",
          "source": "深圳市人力资源和社会保障局",
          "version": "2026-09-01",
          "officialUrl": "http://hrss.sz.gov.cn/xxgk/qtxx/tzgg/content/post_12954949.html",
          "effectiveDate": "2026-09-01"
    },
    {
          "id": "重庆",
          "title": "重庆地区政策适配包",
          "scope": "重庆",
          "status": "最低工资已核验",
          "note": "2025年1月1日起：主城等区县月最低工资2330元、小时23元；其他区县月最低工资2200元、小时22元。",
          "source": "重庆市人力资源和社会保障局",
          "version": "2025-01-01",
          "officialUrl": "https://www.cq.gov.cn/ywdt/jrcq/202501/t20250102_14038331.html",
          "effectiveDate": "2025-01-01"
    },
    {
          "id": "四川",
          "title": "四川地区政策适配包",
          "scope": "四川",
          "status": "人社部汇总，待属地原文复核",
          "note": "人社部截至2026年10月1日汇总：月最低工资分档2330、2200元；小时最低工资分档23、22元。",
          "source": "人力资源和社会保障部全国最低工资汇总",
          "version": "2026-10-01",
          "officialUrl": "https://rst.sc.gov.cn/",
          "effectiveDate": ""
    },
    {
          "id": "贵州",
          "title": "贵州地区政策适配包",
          "scope": "贵州",
          "status": "人社部汇总，待属地原文复核",
          "note": "人社部截至2026年10月1日汇总：月最低工资分档2130、1980、1890元；小时最低工资分档22.4、20.8、19.8元。",
          "source": "人力资源和社会保障部全国最低工资汇总",
          "version": "2026-10-01",
          "officialUrl": "https://rst.guizhou.gov.cn/",
          "effectiveDate": ""
    },
    {
          "id": "云南",
          "title": "云南地区政策适配包",
          "scope": "云南",
          "status": "人社部汇总，待属地原文复核",
          "note": "人社部截至2026年10月1日汇总：月最低工资分档2270、2120、1970元；小时最低工资分档22、21、20元。",
          "source": "人力资源和社会保障部全国最低工资汇总",
          "version": "2026-10-01",
          "officialUrl": "https://hrss.yn.gov.cn/",
          "effectiveDate": ""
    },
    {
          "id": "陕西",
          "title": "陕西地区政策适配包",
          "scope": "陕西",
          "status": "人社部汇总，待属地原文复核",
          "note": "人社部截至2026年10月1日汇总：月最低工资分档2376、2250、2140元；小时最低工资分档23、21.7、20.7元。",
          "source": "人力资源和社会保障部全国最低工资汇总",
          "version": "2026-10-01",
          "officialUrl": "https://hrss.shaanxi.gov.cn/",
          "effectiveDate": ""
    },
    {
          "id": "湖北",
          "title": "湖北地区政策适配包",
          "scope": "湖北",
          "status": "人社部汇总，待属地原文复核",
          "note": "人社部截至2026年10月1日汇总：月最低工资分档2400、2130、1970元；小时最低工资分档24、21.5、20元。",
          "source": "人力资源和社会保障部全国最低工资汇总",
          "version": "2026-10-01",
          "officialUrl": "https://rst.hubei.gov.cn/",
          "effectiveDate": ""
    },
    {
          "id": "湖南",
          "title": "湖南地区政策适配包",
          "scope": "湖南",
          "status": "人社部汇总，待属地原文复核",
          "note": "人社部截至2026年10月1日汇总：月最低工资分档2200、2000、1800元；小时最低工资分档22、20、18元。",
          "source": "人力资源和社会保障部全国最低工资汇总",
          "version": "2026-10-01",
          "officialUrl": "https://rst.hunan.gov.cn/",
          "effectiveDate": ""
    },
    {
          "id": "广西",
          "title": "广西地区政策适配包",
          "scope": "广西",
          "status": "人社部汇总，待属地原文复核",
          "note": "人社部截至2026年10月1日汇总：月最低工资分档2200、2040、1870元；小时最低工资分档22.4、20.7、19元。",
          "source": "人力资源和社会保障部全国最低工资汇总",
          "version": "2026-10-01",
          "officialUrl": "https://rst.gxzf.gov.cn/",
          "effectiveDate": ""
    }
  ]
};
