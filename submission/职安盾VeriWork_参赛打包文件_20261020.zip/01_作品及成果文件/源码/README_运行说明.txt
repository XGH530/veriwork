职安盾 VeriWork 源码与运行说明

一、在线访问
公网地址：http://8.133.222.0/veriwork/
评审测试账号：reviewer2026
评审测试密码：ReviewDemo!2026

二、本地运行
1. 安装 Python 3.10+。
2. 安装依赖：python -m pip install -r requirements.txt
3. 图片 OCR 需安装 Tesseract：
   Ubuntu/Debian: apt-get install -y tesseract-ocr tesseract-ocr-chi-sim tesseract-ocr-chi-tra tesseract-ocr-eng tesseract-ocr-jpn
4. 复制 .env.example 为 .env，配置数据库路径和可选的大模型接口。
5. 启动：python server.py
6. 浏览器访问：http://127.0.0.1:8000

三、说明
- 参赛包不包含 .env、API 密钥、数据库、证据原件或真实用户材料。
- 未配置大模型时，系统使用本地规则、结构化事实、语义回退和法源检索。
- OCR 结果需人工校对；地方政策标准需以官方最新文件为准。
- 作品用于竞赛展示、普法教育和材料整理，不替代律师、仲裁机构或人社部门的最终判断。
